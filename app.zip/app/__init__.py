"""App package for PC Recommendation backend."""

__all__ = ["main", "recommender", "schemas"]
