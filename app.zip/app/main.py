from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.recommender.engine import recommend_pc
from app.recommender.direct_engine import recommend_pc_direct
from app.schemas import UserInput


app = FastAPI(title="PC Recommendation System")

# Allow local frontend dev server to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/recommend_direct")
def recommend_direct(user_input: UserInput):
    return recommend_pc(user_input)


